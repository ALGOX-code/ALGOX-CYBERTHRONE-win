BEGIN TRANSACTION;
CREATE TABLE database_metadata (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
INSERT INTO "database_metadata" VALUES('dataset_version','1.1.0');
INSERT INTO "database_metadata" VALUES('record_count','12');
INSERT INTO "database_metadata" VALUES('created_utc','2026-09-27');
INSERT INTO "database_metadata" VALUES('scope','12 curated historical incident records plus a catalog of 8 public technical datasets; not an exhaustive archive or live feed.');
INSERT INTO "database_metadata" VALUES('update_policy','Append new cited records only after human review. A database entry updates reference data only; it cannot rewrite model weights, detection rules, app code, or binaries.');
CREATE TABLE historical_records (
  record_id TEXT PRIMARY KEY,
  event_date TEXT NOT NULL,
  year INTEGER NOT NULL,
  category TEXT NOT NULL,
  title TEXT NOT NULL,
  summary TEXT NOT NULL,
  defensive_analysis TEXT NOT NULL,
  tags_json TEXT NOT NULL,
  source_url TEXT NOT NULL,
  source_name TEXT NOT NULL,
  content_sha256 TEXT NOT NULL
);
INSERT INTO "historical_records" VALUES('ALGX-HIST-0001','2000-05',2000,'Malware / disruption','ILOVEYOU worm','A mass-mailing worm spread through email attachments and caused widespread disruption and data loss.','Email attachment controls, user awareness, least privilege, and tested offline backups reduce similar impact.','["worm", "email", "social engineering"]','https://csrc.nist.gov/csrc/media/publications/shared/documents/itl-bulletin/itlbul2000-06.pdf','CISA advisory','1bcde58a92eddf2cd1a723ec2decf944132921cafb019b62df093eaa6160ca91');
INSERT INTO "historical_records" VALUES('ALGX-HIST-0002','2010',2010,'Malware / disruption','Stuxnet','A highly targeted worm affected industrial control environments and demonstrated the operational risk of compromised engineering systems.','Segment OT from IT, restrict removable media, inventory engineering workstations, and validate safety controls independently.','["worm", "industrial control", "OT"]','https://www.cisa.gov/uscert/ics/advisories/ICSA-10-272-01','CISA advisory','d059479e75687d1389bd706e32a9446dc88576af09218fc85f96ce687bb5e82d');
INSERT INTO "historical_records" VALUES('ALGX-HIST-0003','2017-05',2017,'Malware / disruption','WannaCry ransomware outbreak','A global ransomware campaign disrupted organizations, including health and critical-infrastructure operators; CISA documented SMB-related exposure and mitigations.','Prioritize supported systems and security updates, restrict legacy SMB exposure, segment networks, and maintain offline recovery copies.','["ransomware", "SMB", "CVE-2017-0144"]','https://www.cisa.gov/news-events/ics-alerts/ics-alert-17-135-01i','CISA alert','a20be81cbe58be4e1f67b0d50dc7c164da234df1a6ae3c86b6d5954b5f8c58ed');
INSERT INTO "historical_records" VALUES('ALGX-HIST-0004','2017-06',2017,'Malware / disruption','NotPetya destructive outbreak','A destructive malware outbreak spread internationally and caused severe business disruption through compromised software distribution and network propagation.','Protect software update paths, segment privileged administration, isolate backups, and rehearse rapid containment and restoration.','["destructive malware", "supply chain", "recovery"]','https://www.cisa.gov/uscert/ncas/alerts/TA17-181A','CISA alert','d522fd77554ffd9dd93f236612754bcb5761811ce84daed54656fdf453b4f350');
INSERT INTO "historical_records" VALUES('ALGX-HIST-0005','2017-03',2017,'Vulnerability','Microsoft Windows SMBv1 vulnerabilities','CVE-2017-0143 through CVE-2017-0148 affected SMBv1 and were associated with major exploitation campaigns.','Apply vendor security updates, disable SMBv1 where possible, limit SMB at network boundaries, and review CISA KEV for current remediation status.','["CVE-2017-0143", "CVE-2017-0144", "SMBv1"]','https://www.cisa.gov/news-events/ics-alerts/ics-alert-17-135-01i','CISA alert','219ecba61786bb8e607663ed107a01ae3dcd3a8e8ea703712a8a46248fdd473d');
INSERT INTO "historical_records" VALUES('ALGX-HIST-0006','2020-12',2020,'Incident / supply chain','SolarWinds Orion compromise','CISA reported active exploitation involving trojanized Orion software updates distributed between March and June 2020.','Constrain build and update trust, monitor identity and control-plane activity, use independent telemetry, and follow incident-specific containment guidance.','["supply chain", "identity", "SUNBURST"]','https://www.cisa.gov/news-events/alerts/2020/12/13/active-exploitation-solarwinds-software','CISA alert','1e7c8c9943f7e6d89c3d10334385fc151b5b1c6138cf3333f2af9c3038fdc5fa');
INSERT INTO "historical_records" VALUES('ALGX-HIST-0007','2021-05',2021,'Incident / ransomware','Colonial Pipeline incident','A ransomware incident led the operator to take pipeline operations offline temporarily, affecting fuel distribution in parts of the United States.','Maintain IT/OT separation, tested continuity plans, clear incident roles, and recovery procedures that do not depend on affected identity services.','["ransomware", "critical infrastructure", "continuity"]','https://www.justice.gov/archives/opa/pr/department-justice-seizes-23-million-cryptocurrency-paid-ransomware-extortionists-darkside','CISA statement','172e180c9e8eb4b37728a11cb4d2b502a10ce7bdc9ece2ac1ef78e4b0b18e080');
INSERT INTO "historical_records" VALUES('ALGX-HIST-0008','2021-12',2021,'Vulnerability','Log4Shell — CVE-2021-44228','A critical issue in Apache Log4j was widely exposed across products and services; responders faced a large asset-discovery and remediation effort.','Inventory software and embedded components, identify internet-facing services, apply vendor fixes, and verify remediation with authenticated asset scans.','["CVE-2021-44228", "Apache Log4j", "dependency"]','https://www.cisa.gov/news-events/alerts/2021/12/22/mitigating-log4shell-and-other-log4j-related-vulnerabilities','CISA advisory','41d92302244d2eafbb1b137eaa568a4d590b7e02ab976712cdef3166c8368533');
INSERT INTO "historical_records" VALUES('ALGX-HIST-0009','2023-06',2023,'Vulnerability / incident','MOVEit Transfer — CVE-2023-34362','CISA and partners documented exploitation of a MOVEit Transfer SQL injection vulnerability and related data theft activity.','Patch affected systems, inspect vendor guidance for compromise, rotate potentially exposed secrets, and review outbound data movement and logs.','["CVE-2023-34362", "MOVEit", "data theft"]','https://www.cisa.gov/news-events/cybersecurity-advisories/aa23-158a','CISA advisory','ed620570aae7218fa636d01ed05026601f11649e725c229584bea745cc43d662');
INSERT INTO "historical_records" VALUES('ALGX-HIST-0010','2023-04',2023,'Cybercrime case','Genesis Market disruption','An international law-enforcement operation disrupted a marketplace selling access credentials and device data stolen from compromised computers.','Use unique passwords and phishing-resistant MFA, revoke active sessions after suspected compromise, and monitor identity-provider sign-ins.','["credential theft", "identity fraud", "law enforcement"]','https://www.justice.gov/archives/opa/pr/criminal-marketplace-disrupted-international-cyber-operation','U.S. DOJ','d3dd2bc08de5772cc99502037f652c788c948489b0ae8a38b420a1841ae107bc');
INSERT INTO "historical_records" VALUES('ALGX-HIST-0011','2024-02',2024,'Cybercrime case','LockBit infrastructure disruption','The U.S., U.K., and international partners announced infrastructure seizures and criminal charges targeting the LockBit ransomware ecosystem.','Prepare recoverable backups, establish a tested incident-response path, and preserve logs and evidence before rebuilding affected systems.','["ransomware", "extortion", "law enforcement"]','https://www.justice.gov/usao-ndca/pr/us-and-uk-disrupt-lockbit-ransomware-variant','U.S. DOJ','4ec5f07301f9d7b20e4be2c514a9a6e92efc42ec3da75ada6f28e276a34e0a70');
INSERT INTO "historical_records" VALUES('ALGX-HIST-0012','2024-07',2024,'Cybercrime case','Andariel / Maui ransomware indictment','The U.S. DOJ announced charges involving ransomware attacks against healthcare providers and follow-on intrusions against other organizations.','Protect clinical availability with segmented networks, offline recovery, MFA for remote access, and rehearsed downtime procedures.','["Maui", "healthcare", "ransomware"]','https://www.justice.gov/archives/opa/pr/north-korean-government-hacker-charged-involvement-ransomware-attacks-targeting-us-hospitals','U.S. DOJ','01f90cbb9043c6c8ec80eb6a70bb3b7246f292d8a2fd80749fecaab7862cf369');
CREATE INDEX idx_historical_year ON historical_records(year);
CREATE INDEX idx_historical_category ON historical_records(category);
CREATE INDEX idx_historical_date ON historical_records(event_date);
CREATE TRIGGER historical_records_append_only_update
BEFORE UPDATE ON historical_records
BEGIN SELECT RAISE(ABORT, 'Historical records are append-only; use a reviewed signed database release.'); END;
CREATE TRIGGER historical_records_append_only_delete
BEFORE DELETE ON historical_records
BEGIN SELECT RAISE(ABORT, 'Historical records are append-only; use a reviewed signed database release.'); END;
CREATE TABLE historical_dataset_sources (
  source_id TEXT PRIMARY KEY,
  category TEXT NOT NULL,
  title TEXT NOT NULL,
  date_coverage TEXT NOT NULL,
  description TEXT NOT NULL,
  source_url TEXT NOT NULL,
  format TEXT NOT NULL,
  handling_note TEXT NOT NULL
);
INSERT INTO historical_dataset_sources VALUES
('SRC-CVE','Vulnerability','CVE List','Publicly disclosed CVEs; ongoing','Official structured CVE record archive.','https://github.com/CVEProject/cvelistV5','CVE JSON 5.0','Use the upstream archive and verify release metadata.'),
('SRC-NVD','Vulnerability','National Vulnerability Database','Historical CVE records; ongoing enrichment','NIST CVE data with enrichment, severity, and product applicability details.','https://nvd.nist.gov/vuln/data-feeds','JSON 2.0','Large bulk downloads; check NIST feed guidance.'),
('SRC-ATTACK','Threat behavior','MITRE ATT&CK STIX','Versioned releases','Versioned Enterprise, Mobile, and ICS tactics, techniques, software, groups, and mitigations.','https://github.com/mitre-attack/attack-stix-data','STIX 2.1 JSON','Check release version and MITRE terms.'),
('SRC-KEV','Vulnerability exploitation','CISA KEV','Catalog history; ongoing updates','Known exploited vulnerabilities catalog used by ALGOX online refresh.','https://www.cisa.gov/known-exploited-vulnerabilities-catalog','JSON / CSV','Catalog membership is not an asset-specific finding.'),
('SRC-CFREDS','Digital forensics','NIST CFReDS','Multiple published scenarios','Documented forensic reference images and ground truth for training and tool validation.','https://www.nist.gov/programs-projects/computer-forensic-reference-data-sets','Disk images / documents','Large forensic images; use a controlled lab and preserve evidence copies.'),
('SRC-CICIDS2017','Network defense research','CIC-IDS2017','2017 capture period','Labeled network flows and PCAPs from a controlled intrusion-detection research testbed.','https://www.unb.ca/cic/datasets/ids-2017.html','PCAP / CSV','Approximately 51 GB total according to the publisher; isolate analysis.'),
('SRC-CAPEC','Attack pattern taxonomy','MITRE CAPEC','Versioned catalog','Structured common attack patterns for threat modeling and defensive analysis.','https://capec.mitre.org/data/','XML / CSV / JSON','Use for defensive taxonomy; not an execution guide.'),
('SRC-IC3','Cybercrime statistics','FBI IC3 annual reports','Annual reports; ongoing','Aggregate complaint and loss statistics, not victim-level case data.','https://www.ic3.gov/AnnualReport/Reports/2025_IC3Report.pdf','PDF / tables','Interpret as reported complaints, not total crime prevalence.');
COMMIT;
