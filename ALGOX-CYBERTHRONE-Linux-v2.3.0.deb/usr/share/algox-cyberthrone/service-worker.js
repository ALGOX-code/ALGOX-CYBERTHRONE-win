const CACHE_NAME='algox-offline-shell-v24';
const APP_FILES=['/','/index.html','/algox-cyberthrone.html','/assistant.html','/daily-news.html','/tools.html','/downloads.html','/installation-guide.html','/assistant-engine.js','/security-tools.js','/security-history-data.js','/security-history-widget.js','/intel-widget.js','/pwa-client.js','/manifest.webmanifest','/security-history.sqlite','/security-history.sql','/algox-cyberthrone-app-icon.png','/windows-platform-icon.svg','/linux-platform-icon.svg','/android-platform-icon.svg','/icons/algox-192.png','/icons/algox-512.png'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE_NAME).then(c=>c.addAll(APP_FILES)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('algox-offline-shell-')&&k!==CACHE_NAME).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{
 const r=e.request;if(r.method!=='GET'||new URL(r.url).origin!==self.location.origin)return;
 if(r.mode==='navigate'){e.respondWith(fetch(r).then(response=>{if(response.ok)caches.open(CACHE_NAME).then(c=>c.put(r,response.clone()));return response;}).catch(async()=>await caches.match(r)||await caches.match('/index.html')));return;}
 e.respondWith(caches.match(r).then(hit=>hit||fetch(r).then(response=>{if(response.ok)caches.open(CACHE_NAME).then(c=>c.put(r,response.clone()));return response;})));
});
