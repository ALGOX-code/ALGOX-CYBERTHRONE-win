(() => {
  const root = document.querySelector('#historyResults');
  const search = document.querySelector('#historySearch');
  const type = document.querySelector('#historyType');
  const year = document.querySelector('#historyYear');
  const status = document.querySelector('#historyStatus');
  const data = window.ALGOX_SECURITY_HISTORY;
  if (!root || !search || !type || !year || !status || !data) return;
  const safe = v => String(v ?? '');
  const records = Array.isArray(data.records) ? data.records : [];
  [...new Set(records.map(x => x.type))].sort().forEach(v => { const o=document.createElement('option');o.value=v;o.textContent=v;type.append(o); });
  [...new Set(records.map(x => x.year))].sort((a,b)=>b-a).forEach(v => { const o=document.createElement('option');o.value=v;o.textContent=v;year.append(o); });
  function render() {
    const q=search.value.trim().toLowerCase();
    const found=records.filter(r=>(!type.value||r.type===type.value)&&(!year.value||String(r.year)===year.value)&&[r.title,r.summary,r.analysis,r.type,...(r.tags||[])].some(x=>safe(x).toLowerCase().includes(q))).sort((a,b)=>safe(b.date).localeCompare(safe(a.date)));
    status.textContent=`${found.length} of ${records.length} curated records · ${safe(data.scope)}`;
    root.replaceChildren();
    if(!found.length){root.textContent='No matching historical records.';return;}
    for(const r of found){
      const card=document.createElement('article');card.className='intel-row';
      const heading=document.createElement('strong');heading.textContent=`${safe(r.year)} · ${safe(r.type)}`;
      const title=document.createElement('div');title.textContent=r.title;
      const summary=document.createElement('p');summary.textContent=r.summary;
      const analysis=document.createElement('small');analysis.textContent=`Defensive analysis: ${safe(r.analysis)}`;
      const source=document.createElement('p');const a=document.createElement('a');a.href=r.source;a.target='_blank';a.rel='noopener noreferrer';a.textContent=`Primary source: ${safe(r.sourceName)} ↗`;source.append(a);
      card.append(heading,title,summary,analysis,source);root.append(card);
    }
  }
  [search,type,year].forEach(el=>el.addEventListener('input',render));render();
})();
