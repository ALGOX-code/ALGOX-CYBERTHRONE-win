(()=>{
 const status=document.querySelector('#connectionStatus');
 const install=document.querySelector('#installApp');
 let promptEvent;
 let registration;
 let updateTimer;
 function updateConnection(){
  if(!status)return;
  if(!navigator.onLine){status.textContent='Offline · saved workspace available';return;}
  status.textContent=registration?'Online · automatic web updates enabled':'Online · offline copy available after setup';
 }
 function showUpdateNotice(message,action){
  let notice=document.querySelector('#algoxUpdateNotice');
  if(!notice){
   notice=document.createElement('div');
   notice.id='algoxUpdateNotice';
   notice.setAttribute('role','status');
   notice.style.cssText='position:fixed;z-index:20;right:18px;bottom:18px;max-width:min(420px,calc(100vw - 36px));padding:13px 15px;border:1px solid #315d3e;border-radius:10px;background:#0d1b12;color:#e8f5ec;box-shadow:0 12px 40px #0009;font:13px/1.5 system-ui,sans-serif';
   document.body.appendChild(notice);
  }
  notice.replaceChildren(document.createTextNode(message));
  if(action){
   const button=document.createElement('button');
   button.type='button';button.textContent='Reload workspace';
   button.style.cssText='margin-left:10px;border:1px solid #58f59b;border-radius:6px;padding:5px 9px;background:#102117;color:#b5ffd4;cursor:pointer';
   button.addEventListener('click',()=>location.reload());notice.appendChild(button);
  }
 }
 window.addEventListener('online',updateConnection);
 window.addEventListener('offline',updateConnection);
 if('serviceWorker'in navigator&&/^https?:$/.test(location.protocol)){
  navigator.serviceWorker.register('/service-worker.js').then(reg=>{
   registration=reg;updateConnection();
   if(reg.waiting&&navigator.serviceWorker.controller)showUpdateNotice('A new hosted workspace release is ready.',true);
   reg.addEventListener('updatefound',()=>{
    const worker=reg.installing;
    if(!worker)return;
    worker.addEventListener('statechange',()=>{
     if(worker.state==='installed'&&navigator.serviceWorker.controller)showUpdateNotice('A new workspace release is ready. Reload to use it.',true);
    });
   });
   const check=()=>{if(navigator.onLine)reg.update().catch(()=>{});};
   window.addEventListener('focus',check);
   updateTimer=window.setInterval(check,6*60*60*1000);
   updateConnection();
  }).catch(()=>{if(status)status.textContent='Local assistant works; offline website setup is unavailable.';});
  let reloading=false;
  navigator.serviceWorker.addEventListener('controllerchange',()=>{
   if(reloading)return;
   reloading=true;
   showUpdateNotice('Workspace updated. Reload this page to use the latest version.',true);
  });
 }
 window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();promptEvent=e;if(install)install.hidden=false;});
 install?.addEventListener('click',async()=>{if(!promptEvent)return;promptEvent.prompt();await promptEvent.userChoice;promptEvent=null;install.hidden=true;});
 window.addEventListener('pagehide',()=>{if(updateTimer)clearInterval(updateTimer);});
 updateConnection();
})();
