#!/usr/bin/env python3
import json
import os
import re
import threading
import time
import urllib.parse
import urllib.request
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

APP_DIR = Path('/usr/share/algox-cyberthrone')
CACHE = Path.home() / '.local/share/algox-cyberthrone/cisa-kev.json'
FEED = 'https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json'
MAX_BYTES = 15_000_000
lock = threading.Lock()

def valid_feed(raw):
    data = json.loads(raw)
    if 'Known Exploited Vulnerabilities' not in data.get('title', ''):
        raise ValueError('Feed title did not match the expected CISA KEV catalog.')
    records = data.get('vulnerabilities')
    if not isinstance(records, list) or not records or len(records) > 100_000:
        raise ValueError('Catalog record count is invalid.')
    required = ('dateAdded', 'vendorProject', 'product', 'vulnerabilityName', 'shortDescription', 'requiredAction')
    for item in records:
        if not isinstance(item, dict) or not re.fullmatch(r'CVE-[0-9]{4}-[0-9]{4,}', str(item.get('cveID', ''))):
            raise ValueError('Catalog contains an invalid CVE record.')
        if any(not isinstance(item.get(key), str) for key in required):
            raise ValueError('Catalog record is missing expected fields.')
    return data

def refresh():
    with lock:
        request = urllib.request.Request(FEED, headers={'User-Agent': 'ALGOX-CYBERTHRONE/1.0 defensive-intel'})
        with urllib.request.urlopen(request, timeout=25) as response:
            final = urllib.parse.urlparse(response.geturl())
            if final.scheme != 'https' or final.hostname != 'www.cisa.gov':
                raise ValueError('Feed response was not served from the official HTTPS host.')
            raw = response.read(MAX_BYTES + 1)
        if len(raw) > MAX_BYTES:
            raise ValueError('Feed exceeds the 15 MB safety limit.')
        catalog = valid_feed(raw)
        CACHE.parent.mkdir(parents=True, exist_ok=True)
        temp = CACHE.with_suffix('.tmp')
        temp.write_bytes(raw)
        os.replace(temp, CACHE)
        return {'updatedUtc': time.strftime('%Y-%m-%d %H:%M UTC', time.gmtime()), 'catalog': catalog}

def cached():
    if not CACHE.exists():
        raise FileNotFoundError('No saved CISA catalog yet. Connect to the internet and refresh.')
    return {'updatedUtc': time.strftime('%Y-%m-%d %H:%M UTC', time.gmtime(CACHE.stat().st_mtime)), 'catalog': valid_feed(CACHE.read_bytes())}

def refresh_if_due():
    if not CACHE.exists() or time.time() - CACHE.stat().st_mtime >= 86400:
        try:
            refresh()
        except Exception:
            pass
    timer = threading.Timer(86400, refresh_if_due)
    timer.daemon = True
    timer.start()

class Handler(BaseHTTPRequestHandler):
    def respond(self, status, payload, content_type='application/json; charset=utf-8'):
        body = payload if isinstance(payload, bytes) else json.dumps(payload).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Frame-Options', 'SAMEORIGIN')
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == '/api/kev':
            try:
                self.respond(200, cached())
            except Exception as exc:
                self.respond(503, {'error': str(exc)})
            return
        clean_path = self.path.split('?')[0].lstrip('/')
        if not clean_path:
            clean_path = 'index.html'
        file_path = APP_DIR / clean_path
        if file_path.is_file():
            ct = 'text/plain'
            if clean_path.endswith('.html'): ct = 'text/html; charset=utf-8'
            elif clean_path.endswith('.js'): ct = 'text/javascript; charset=utf-8'
            elif clean_path.endswith('.png'): ct = 'image/png'
            elif clean_path.endswith('.svg'): ct = 'image/svg+xml'
            elif clean_path.endswith('.json'): ct = 'application/json'
            elif clean_path.endswith('.sqlite'): ct = 'application/x-sqlite3'
            try:
                self.respond(200, file_path.read_bytes(), ct)
            except OSError:
                self.respond(500, {'error': 'Failed to read file'})
        else:
            self.respond(404, {'error': 'Not found'})

    def do_POST(self):
        if self.path != '/api/refresh':
            self.respond(404, {'error': 'Not found'})
            return
        if self.headers.get('Origin') != f'http://127.0.0.1:{self.server.server_port}':
            self.respond(403, {'error': 'Refresh requests must come from the local ALGOX page.'})
            return
        try:
            self.respond(200, refresh())
        except Exception as exc:
            self.respond(502, {'error': str(exc)})

    def log_message(self, *_args):
        pass

def main():
    server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    server.daemon_threads = True
    threading.Thread(target=refresh_if_due, daemon=True).start()
    url = f'http://127.0.0.1:{server.server_port}/index.html'
    webbrowser.open(url)
    print(f'ALGOX local workspace: {url}')
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        server.server_close()

if __name__ == '__main__':
    main()
