(() => {
  const status = document.querySelector('#intelStatus');
  const list = document.querySelector('#intelResults');
  const search = document.querySelector('#intelSearch');
  const refresh = document.querySelector('#intelRefresh');
  if (!status || !list || !search || !refresh) return;
  let snapshot = null;
  const esc = value => String(value || '');
  function render(data) {
    snapshot = data && data.catalog ? data : { catalog: data, updatedUtc: '' };
    const catalog = snapshot.catalog;
    if (!catalog || !Array.isArray(catalog.vulnerabilities)) throw new Error('Unexpected catalog format.');
    const rows = catalog.vulnerabilities;
    const q = search.value.trim().toLowerCase();
    const matches = rows.filter(item => [item.cveID,item.vendorProject,item.product,item.vulnerabilityName,item.shortDescription].some(x => esc(x).toLowerCase().includes(q)))
      .sort((a,b) => esc(b.dateAdded).localeCompare(esc(a.dateAdded))).slice(0,30);
    status.textContent = `CISA KEV · ${rows.length.toLocaleString()} records · ${snapshot.updatedUtc ? `saved ${snapshot.updatedUtc}` : 'saved locally'}`;
    list.replaceChildren();
    if (!matches.length) { list.textContent = 'No matching records in the saved catalog.'; return; }
    for (const item of matches) {
      const card = document.createElement('article'); card.className = 'intel-row';
      const heading = document.createElement('strong'); heading.textContent = `${esc(item.cveID)} · ${esc(item.dateAdded)}`;
      const product = document.createElement('div'); product.textContent = `${esc(item.vendorProject)} · ${esc(item.product)} — ${esc(item.vulnerabilityName)}`;
      const detail = document.createElement('p'); detail.textContent = esc(item.shortDescription);
      const action = document.createElement('small'); action.textContent = `Vendor action: ${esc(item.requiredAction)}`;
      card.append(heading, product, detail, action); list.append(card);
    }
  }
  window.algoxIntelUpdated = raw => { try { render(typeof raw === 'string' ? JSON.parse(raw) : raw); status.dataset.state='ok'; } catch(e) { status.textContent=`Could not read updated catalog: ${e.message}`; } };
  window.algoxIntelError = message => { status.textContent=`Update unavailable; keeping saved data. ${esc(message)}`; };
  async function readLocal() {
    if (window.AlgoxIntel && typeof window.AlgoxIntel.getCachedKev === 'function') {
      const raw = window.AlgoxIntel.getCachedKev(); if (raw) render(JSON.parse(raw)); else status.textContent='No saved catalog yet. Connect to the internet and select Refresh.';
      return;
    }
    if (location.protocol === 'http:' && ['127.0.0.1','localhost'].includes(location.hostname)) {
      const response = await fetch('/api/kev'); if (!response.ok) throw new Error('No local catalog cache is available yet.'); render(await response.json()); return;
    }
    status.innerHTML='Automatic catalog refresh is available in the installed Linux and Android apps. <a href="https://www.cisa.gov/known-exploited-vulnerabilities-catalog" target="_blank" rel="noopener">Open CISA KEV ↗</a>';
  }
  refresh.addEventListener('click', async () => {
    refresh.disabled = true; status.textContent='Checking the official CISA feed over HTTPS…';
    try {
      if (window.AlgoxIntel && typeof window.AlgoxIntel.refreshKev === 'function') { window.AlgoxIntel.refreshKev(); return; }
      if (location.protocol === 'http:' && ['127.0.0.1','localhost'].includes(location.hostname)) {
        const response=await fetch('/api/refresh',{method:'POST'}); const data=await response.json(); if (!response.ok) throw new Error(data.error||'Update failed.'); render(data); return;
      }
      status.textContent='Use the installed Linux/Android app to refresh the local catalog, or open CISA’s source page.';
    } catch(e) { window.algoxIntelError(e.message); }
    finally { refresh.disabled = false; }
  });
  search.addEventListener('input', () => { if (snapshot) render(snapshot); });
  readLocal().catch(e => { status.textContent=`Saved catalog unavailable. ${e.message}`; });
  if (location.protocol === 'http:' && ['127.0.0.1','localhost'].includes(location.hostname)) setInterval(() => readLocal().catch(()=>{}), 15*60*1000);
})();
