(() => {
  const tools = [
    {name:'Nmap', category:'Pentest & vulnerability', summary:'Network discovery and service inventory for explicitly authorized assets.', url:'https://nmap.org/docs.html', risk:'Active network traffic'},
    {name:'Metasploit Framework', category:'Pentest', summary:'Security validation framework; use only in a controlled lab or written scope.', url:'https://docs.metasploit.com/', risk:'Exploitation-capable'},
    {name:'Wireshark', category:'Pentest & forensics', summary:'Inspect packet captures collected with permission; protect captures as sensitive evidence.', url:'https://www.wireshark.org/docs/', risk:'Sensitive traffic data'},
    {name:'sqlmap', category:'Pentest', summary:'Automated SQL injection testing. Restrict to intentionally vulnerable labs or authorized systems.', url:'https://github.com/sqlmapproject/sqlmap', risk:'Active testing'},
    {name:'OWASP ZAP', category:'Pentest & vulnerability', summary:'Web application proxy and scanner; use passive checks first and explicit scope for active scans.', url:'https://www.zaproxy.org/docs/', risk:'Active web scans'},
    {name:'Hashcat', category:'Pentest', summary:'Password recovery and hash auditing for hashes you are authorized to assess.', url:'https://hashcat.net/wiki/', risk:'Credential recovery'},
    {name:'Strix', category:'AI pentest', summary:'Open-source AI-assisted security testing project; isolate it and constrain targets before any run.', url:'https://docs.strix.ai/', risk:'Autonomous testing'},
    {name:'PentestGPT', category:'AI pentest', summary:'Research-derived LLM-assisted penetration-testing project; review its current repository and model requirements.', url:'https://github.com/GreyDGL/PentestGPT', risk:'May guide active testing'},
    {name:'PentAGI', category:'AI pentest', summary:'Experimental autonomous agent framework. Do not connect to production assets or unrestricted networks.', url:'https://github.com/vxcontrol/pentagi', risk:'Autonomous testing'},
    {name:'HexStrike AI', category:'AI pentest', summary:'Third-party MCP security automation project; inspect code, permissions, and dependencies before use.', url:'https://github.com/0x4m4/hexstrike-ai', risk:'Tool execution'},
    {name:'Autopsy', category:'Digital forensics', summary:'Digital investigation interface. Work from verified forensic copies and preserve case audit trails.', url:'https://www.autopsy.com/', risk:'Evidence handling'},
    {name:'The Sleuth Kit', category:'Digital forensics', summary:'Open-source command-line tools for disk-image and file-system analysis.', url:'https://www.sleuthkit.org/', risk:'Evidence handling'},
    {name:'Bulk Extractor', category:'Digital forensics', summary:'Feature extraction from digital evidence; preserve the original and record tool/version details.', url:'https://github.com/simsong/bulk_extractor', risk:'Evidence handling'},
    {name:'CAINE', category:'Digital forensics', summary:'Forensic-focused Linux environment; verify image checksums and use write blockers for acquisition.', url:'https://www.caine-live.net/', risk:'Forensic workstation'},
    {name:'SIFT Workstation', category:'Digital forensics', summary:'SANS forensic and incident-response workstation with a collection of analysis tools.', url:'https://www.sans.org/tools/sift-workstation', risk:'Forensic workstation'},
    {name:'Zeke / Zeek', category:'Digital forensics', summary:'“Zeke” could not be verified as a distinct DFIR project; Zeek may be the intended network-analysis tool. Confirm the name.', url:'https://zeek.org/', risk:'Name needs confirmation'},
    {name:'ClamAV', category:'Vulnerability & malware', summary:'Signature-based antivirus toolkit; keep signatures current and treat clean results as limited coverage.', url:'https://docs.clamav.net/', risk:'Detection coverage varies'},
    {name:'OpenVAS / Greenbone Community Edition', category:'Vulnerability', summary:'Vulnerability management and scanning stack; only scan assets you own or are authorized to assess.', url:'https://greenbone.github.io/docs/latest/', risk:'Active network scans'},
    {name:'YARA', category:'Vulnerability & malware', summary:'Pattern-matching rules for files and processes; rules require review and can produce false positives.', url:'https://yara.readthedocs.io/en/stable/', risk:'Rule quality varies'},
    {name:'Nikto', category:'Vulnerability', summary:'Web-server checks that can create traffic and alerts; use against explicitly scoped systems.', url:'https://github.com/sullo/nikto', risk:'Active web scans'},
    {name:'OnionScan', category:'Dark-web intelligence', summary:'A legacy research tool for onion-service analysis. This app does not crawl onion services.', url:'https://github.com/s-rah/onionscan', risk:'Do not crawl from ALGOX'},
    {name:'OWASP TorBot (attribution unverified)', category:'Dark-web intelligence', summary:'The OWASP attribution could not be verified. Treat TorBot as an untrusted third-party research project until its maintainer and source are confirmed.', url:'https://github.com/DedSecInside/TorBot', risk:'Attribution needs confirmation'},
    {name:'MISP', category:'Dark-web intelligence', summary:'Threat-intelligence sharing and IOC management; use trusted feeds and validate context before action.', url:'https://misp-project.org/documentation/', risk:'Feed quality varies'},
    {name:'Ahmia', category:'Dark-web intelligence', summary:'A public onion-service search/indexing project. Search results are untrusted and are not proof of a threat.', url:'https://ahmia.fi/', risk:'Untrusted external content'},
    {name:'SpiderFoot', category:'Dark-web intelligence', summary:'OSINT automation platform; use passive sources where possible and only assess assets within scope.', url:'https://www.spiderfoot.net/', risk:'May contact third parties'}
  ];
  window.ALGOX_TOOLS = Object.freeze(tools.map(Object.freeze));

  const grid = document.querySelector('#toolGrid');
  if (grid) {
    const search = document.querySelector('#toolSearch');
    const filter = document.querySelector('#toolCategory');
    const count = document.querySelector('#toolCount');
    const categories = [...new Set(tools.map(x => x.category))];
    for (const category of categories) {
      const option = document.createElement('option'); option.value = category; option.textContent = category; filter?.append(option);
    }
    const render = () => {
      const q = (search?.value || '').trim().toLowerCase();
      const category = filter?.value || '';
      const matches = tools.filter(t => (!category || t.category === category) && (!q || `${t.name} ${t.category} ${t.summary} ${t.risk}`.toLowerCase().includes(q)));
      grid.replaceChildren();
      for (const tool of matches) {
        const card = document.createElement('article'); card.className = 'card tool-card';
        const head = document.createElement('div'); head.className = 'tool-card-head';
        const group = document.createElement('span'); group.className = 'tag'; group.textContent = tool.category;
        const status = document.createElement('span'); status.className = 'tool-status'; status.textContent = 'REFERENCE ONLY'; head.append(group, status);
        const title = document.createElement('h3'); title.textContent = tool.name;
        const description = document.createElement('p'); description.textContent = tool.summary;
        const risk = document.createElement('small'); risk.className = 'tool-risk'; risk.textContent = `Safety note · ${tool.risk}`;
        const link = document.createElement('a'); link.className = 'btn soft'; link.href = tool.url; link.target = '_blank'; link.rel = 'noopener noreferrer'; link.textContent = 'Official project / docs ↗';
        card.append(head, title, description, risk, link); grid.append(card);
      }
      if (count) count.textContent = `${matches.length} of ${tools.length} listed tools`;
      if (!matches.length) { const empty = document.createElement('p'); empty.className = 'result'; empty.textContent = 'No tools match this search.'; grid.append(empty); }
    };
    search?.addEventListener('input', render); filter?.addEventListener('change', render); render();
  }
})();
